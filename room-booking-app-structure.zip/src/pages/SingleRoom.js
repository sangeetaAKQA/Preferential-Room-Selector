import React, { Component } from "react";

export default class SingleRoom extends Component {
  render() {
    return <div>hello from single room page</div>;
  }
}
